package prosjekt;

public interface ISaveHandler {
    
    void save(Board board);
    Board load();
    
}
