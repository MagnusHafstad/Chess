/**
 * @author hal
 *
 */
open module minegenkode {
	requires javafx.base;
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.graphics;
}
